create
    definer = root@localhost procedure rand_eorh()
BEGIN
	DECLARE i INT DEFAULT 1;
	DECLARE num INT;
	DECLARE num2 INT;
	select COUNT(1) FROM cims_person INTO num;
	while i<=num do
		SET num2=1+ROUND(RAND()*2,0);
		case num2
			when 1 then
				UPDATE cims_person SET estate= 0,heating=RIGHT(BIN(num2),1)  WHERE id=i;
			ELSE
				UPDATE cims_person SET estate= LEFT(BIN(num2),1) ,heating=RIGHT(BIN(num2),1)  WHERE id=i;
		end case;
		SET i=i+1;
	end while;
END;

